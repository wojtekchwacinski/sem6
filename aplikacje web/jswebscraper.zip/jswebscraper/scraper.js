const { JSDOM } = require('jsdom');
const request = require('request');

const url = 'https://www.aaaauto.pl/pl/informacje-prasowe/ranking-tanich-i-oszczednych-aut-uzywanych/article.html?id=46847';

const myDict = new Map();
const myList = [];


request(url, (error, response, body) => {
    if (error) {
        console.error('Błąd:', error);
        return;
    }

    if (response && response.statusCode === 200) {
      
        const dom = new JSDOM(body);

     
        const tables = dom.window.document.querySelectorAll('table');

   
        tables.forEach(table => {
          
            const rows = table.querySelectorAll('tbody tr');

            rows.forEach(row => {
             
                const paragraphs = row.querySelectorAll('p');

                paragraphs.forEach(paragraph => {

                    const spans = paragraph.querySelectorAll('span');

               
                    spans.forEach((span, index) => {
                        if((index + 1) % 5 == 0){
                           // console.log('Zawartość span:');
                            //console.log(span.textContent.trim());
                            //console.log('============================================');
                            myList.push(span.textContent.trim());
                     }
                    });
                });

            });
        });

    } else {
        console.error('Nieudane żądanie, status:', response.statusCode);
    }
    //console.log(myList);
    const usuniete = myList.slice(8)
    const usunieteBezPrzecinek = usuniete.map(element => element.replace(/,/g, '.'));
    const usunieteBezSpacji = usunieteBezPrzecinek.map(element => element.replace(/\s/g, ''));

    const result = [[], [], [], [], [], [], [], [], [], []];
    let x = 0;
    let l = 0;
    for (let i = 0; i < usunieteBezSpacji.length; i++) {
        
        if(i % 5 == 0){
            console.log("Nazwa auta: ", usunieteBezSpacji[i]);
            result[l].push(usunieteBezSpacji[i]);
        }
        else if (i % 5 == 1){
            console.log("Spalanie: ", usunieteBezSpacji[i]);
            result[l].push(usunieteBezSpacji[i]);
        }
        else if (i % 5 == 2){
            console.log("Mediana ceny: ", usunieteBezSpacji[i]);
            result[l].push(usunieteBezSpacji[i]);
            
        }
        else if (i % 5 == 3){
            console.log("Mediana przebiegu: ", usunieteBezSpacji[i]);
            result[l].push(usunieteBezSpacji[i]);
            console.log("Przybliżona ilość litrów paliwa które spalił: ", parseFloat(usunieteBezSpacji[i])*parseFloat(usunieteBezSpacji[i-2]));
            result[l].push(parseFloat(usunieteBezSpacji[i])*parseFloat(usunieteBezSpacji[i-2]));
        }
        else{
            console.log("Mediana wieku: ", usunieteBezSpacji[i]);
            result[l].push(usunieteBezSpacji[i]);
            console.log("Mniej wiecej ile przejechał w rok: ", parseInt(usunieteBezSpacji[i-1])/ parseFloat(usunieteBezSpacji[i]));
            result[l].push(parseInt(usunieteBezSpacji[i-1])/ parseFloat(usunieteBezSpacji[i]));
        }

        x = x + 1;
        if (x % 5 == 0){
            l = l + 1;
        }

      }
      result.sort((a,b) => a[4] - b[4]);
      console.log(result)

});
