<?php session_start(); ?>

<!DOCTYPE html>
<html>
    <body>

<a href="form06_post.php">Link do dodawania pracowników</a>
<br>
<?php




if (isset($_SESSION['blad']) && $_SESSION['blad'] == 22){
    echo "jest cacy<br>";
    $_SESSION['blad'] = 0;
}

$link = mysqli_connect("localhost", "scott", "tiger", "instytut");
if (!$link) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

$sql = "SELECT * FROM pracownicy";
$result = $link->query($sql);
foreach ($result as $v) {
echo $v["ID_PRAC"]." ".$v["NAZWISKO"]."<br/>";
}
$result->free();
$link->close();




?>



</body>
</html>